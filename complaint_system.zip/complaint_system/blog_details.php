<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "db.php";

// Check DB connection
if(!$conn){
    die("Database connection failed: " . mysqli_connect_error());
}

// Check ID
if(!isset($_GET['id']) || empty($_GET['id'])){
    die("Invalid request: ID missing");
}

$id = intval($_GET['id']);

// Query
$sql = "SELECT * FROM blog_posts WHERE id = $id";
$result = mysqli_query($conn, $sql);

// Check query
if(!$result){
    die("Query Error: " . mysqli_error($conn));
}

// Fetch data
$row = mysqli_fetch_assoc($result);

// Check data exists
if(!$row){
    die("No post found with this ID");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo $row['title']; ?></title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(to right, #eef2f3, #dfe9f3);
}

/* HEADER */
header{
    background: linear-gradient(45deg, #363435, #bdb4b2);
    color:white;
    padding:25px;
    text-align:center;
    font-size:26px;
    font-weight:bold;
}

/* CONTAINER */
.container{
    width:90%;
    max-width:900px;
    margin:40px auto;
}

/* BLOG BOX */
.blog-box{
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

/* TITLE */
.title{
    font-size:28px;
    margin-bottom:15px;
    color:#333;
}

/* META */
.meta{
    color:gray;
    font-size:14px;
    margin-bottom:20px;
}

/* CONTENT */
.content{
    font-size:17px;
    color:#444;
    line-height:1.8;
}

/* BACK BUTTON */
.back-btn{
    display:inline-block;
    margin-top:25px;
    padding:10px 18px;
    background:#ff4b2b;
    color:white;
    text-decoration:none;
    border-radius:25px;
    transition:0.3s;
}

.back-btn:hover{
    background:#ff416c;
}

/* RESPONSIVE */
@media(max-width:768px){
    .title{
        font-size:22px;
    }
}

</style>

</head>

<body>

<header>Blog Details</header>

<div class="container">

    <div class="blog-box">

        <div class="title">
            <?php echo $row['title']; ?>
        </div>

        <div class="meta">
            By <b><?php echo $row['author']; ?></b> |
            <?php echo date("d M Y", strtotime($row['created_at'])); ?>
        </div>

        <div class="content">
            <?php echo nl2br($row['content']); ?>
        </div>

        <a href="blog.php" class="back-btn">← Back to Blog</a>

    </div>

</div>

</body>
</html>