<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$success = "";
$error = "";

if (isset($_POST['submit'])) {

    $user_id = $_SESSION['user_id'];
    $subject = trim($_POST['subject']);
    $description = trim($_POST['description']);

    // Prepared statement (secure)
    $stmt = $conn->prepare("INSERT INTO complaints (user_id, subject, description) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $subject, $description);

    if ($stmt->execute()) {
        $success = "Complaint submitted successfully!";
    } else {
        $error = "Something went wrong!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Submit Complaint</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(170deg,gray,white);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-weight:bold;
}
.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}


.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
}

.nav-links a:hover{
    color:gray;
}

.logout{
    background:black;
    padding:8px 15px;
    border-radius:20px;
    text-decoration:none;
    color:white;
}

/* CONTAINER */
.wrapper{
    display:flex;
    justify-content:center;
    align-items:center;
    margin-top:50px;
}

/* CARD */
.container{
    background:rgba(26, 22, 22, 0.15);
    backdrop-filter:blur(15px);
    padding:30px;
    border-radius:15px;
    width:400px;
    color:white;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.container h2{
    text-align:center;
    margin-bottom:20px;
}

/* INPUT */
.input-box{
    margin-bottom:15px;
}

input, textarea{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    outline:none;
}

textarea{
    resize:none;
    height:120px;
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background:black;
    border:none;
    color: whitesmoke;
    border-radius:25px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:gray;
}

/* ALERT */
.success{
    background:#28a745;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    text-align:center;
}

.error{
    background:#ff4d4d;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    text-align:center;
}

/* RESPONSIVE */
@media(max-width:768px){
    .navbar{
        flex-direction:column;
        gap:10px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
     <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>

    <ul class="nav-links">
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="complaint.php">Complaint</a></li>
        <li><a href="blog.php">Blog</a></li>
    </ul>

    <a href="logout.php" class="logout">Logout</a>
</nav>

<!-- FORM -->
<div class="wrapper">
<div class="container">

<h2>Submit Complaint</h2>

<p style="text-align:center; margin-bottom:10px;">
Welcome, <?php echo $_SESSION['name']; ?> 👋
</p>

<?php if($success != ""){ ?>
<div class="success"><?php echo $success; ?></div>
<?php } ?>

<?php if($error != ""){ ?>
<div class="error"><?php echo $error; ?></div>
<?php } ?>

<form method="POST">

<div class="input-box">
    <input type="text" name="subject" placeholder="Enter Subject" required>
</div>

<div class="input-box">
    <textarea name="description" placeholder="Enter Complaint Details" required></textarea>
</div>

<button type="submit" name="submit">Submit Complaint</button>

</form>

</div>
</div>

</body>
</html>