<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resources Page</title>
	
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
        }

        .header {
            text-align: center;
            padding: 40px;
            background: #333;
            color: white;
        }

        .resources-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            padding: 30px;
        }

        .resource-box {
            background: white;
            width: 250px;
            margin: 15px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: 0.3s;
        }

        .resource-box:hover {
            transform: scale(1.05);
        }

        .resource-icon {
            font-size: 40px;
            margin-bottom: 10px;
            color: #333;
        }

        .resource-box a {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: #333;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }

        .resource-box a:hover {
            background: #555;
        }
    </style>
</head>

<body>
<!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
        <ul class="nav-links">
            <li><a href="Features.php">Features</a></li>
            <li><a href="Blog.php">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="Resources.php">Resources</a></li>
        </ul>
        <div class="nav-right">
            <!-- <button class="btn-outline">Sign up</button> -->
            <button class="btn-outline" onclick="window.location.href='register.php'">
                Sign up
            </button>

            <!-- <button class="btn-primary">Login</button> -->
            <button class="btn-primary" onclick="window.location.href='login.php'">
                Login
        </div>
    </nav>
    <div class="header">
        <h1>Project Resources</h1>
        <p>Explore useful files, guides, and tutorials for this project</p>
    </div>

    <div class="resources-container">

        <div class="resource-box">
            <div class="resource-icon"><i class="fa-solid fa-file-code"></i></div>
            <h3>Project Source Code</h3>
            <p>Download the full project code in PHP & MySQL.</p>
            <a href="downloads/project.zip" download>Download</a>
        </div>

        <div class="resource-box">
            <div class="resource-icon"><i class="fa-solid fa-book"></i></div>
            <h3>Documentation</h3>
            <p>Read detailed guides on setting up and using the project.</p>
            <a href="downloads/documentation.pdf" download>Download</a>
        </div>

        <div class="resource-box">
            <div class="resource-icon"><i class="fa-solid fa-video"></i></div>
            <h3>Tutorial Video</h3>
            <p>Step-by-step video guide to help you get started.</p>
            <a href="downloads/tutorial.mp4" download>Download</a>
        </div>

        <div class="resource-box">
            <div class="resource-icon"><i class="fa-solid fa-database"></i></div>
            <h3>Database Backup</h3>
            <p>Download the MySQL database backup for this project.</p>
            <a href="downloads/database.sql" download>Download</a>
        </div>

    </div>

</body>

</html>