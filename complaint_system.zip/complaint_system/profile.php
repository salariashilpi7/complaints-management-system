<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$msg = "";

// Fetch user data
$user = $conn->query("SELECT * FROM users WHERE id='$user_id'")->fetch_assoc();

// UPDATE PROFILE
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $email = $_POST['email'];

    $conn->query("UPDATE users SET name='$name', email='$email' WHERE id='$user_id'");
    $_SESSION['name'] = $name;

    $msg = "✅ Profile updated successfully!";
}

// CHANGE PASSWORD
if(isset($_POST['change_password'])){
    $old = $_POST['old_password'];
    $new = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    if(password_verify($old, $user['password'])){
        $conn->query("UPDATE users SET password='$new' WHERE id='$user_id'");
        $msg = "🔒 Password changed successfully!";
    } else {
        $msg = "❌ Old password is incorrect!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(170deg,gray,white);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(40, 40, 40, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-size:18px;
    font-weight:bold;
}.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
}

.logout{
    background:black;
    color:white;
    padding:8px 15px;
    border-radius:20px;
    text-decoration:none;
}

/* CONTAINER */
.container{
    width:90%;
    max-width:900px;
    margin:40px auto;
    color:black;
}

/* CARD */
.card{
    background:rgba(100, 97, 97, 0.15);
    backdrop-filter:blur(15px);
    padding:30px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
    margin-bottom:20px;
}

/* TITLE */
.title{
    font-size:24px;
    margin-bottom:20px;
}

/* FORM */
.form-group{
    margin-bottom:15px;
}

label{
    display:block;
    margin-bottom:5px;
}

input{
    width:100%;
    padding:10px;
    border:none;
    border-radius:8px;
    outline:none;
}

/* BUTTON */
.btn{
    padding:10px 20px;
    background:black;
    border:none;
    color: whitesmoke;
    border-radius:25px;
    font-weight:bold;
    cursor:pointer;
}

.btn:hover{
    background:gray;
}

/* MESSAGE */
.msg{
    margin-bottom:15px;
    font-weight:bold;
}

/* RESPONSIVE */
@media(max-width:768px){
    .navbar{
        flex-direction:column;
        gap:10px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>

    <ul class="nav-links">
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="complaint.php">Complaint</a></li>
        <li><a href="view_complaints.php">My Complaints</a></li>
        <li><a href="profile.php">Profile</a></li>
    </ul>

    <a href="logout.php" class="logout">Logout</a>
</nav>

<div class="container">

<?php if($msg!=""){ ?>
    <div class="msg"><?php echo $msg; ?></div>
<?php } ?>

<!-- PROFILE UPDATE -->
<div class="card">
    <div class="title">👤 My Profile</div>

    <form method="POST">
        <div class="form-group">
            <label>Name</label>
            <input type="text" name="name" value="<?php echo $user['name']; ?>" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
        </div>

        <button type="submit" name="update" class="btn">Update Profile</button>
    </form>
</div>

<!-- CHANGE PASSWORD -->
<div class="card">
    <div class="title">🔒 Change Password</div>

    <form method="POST">
        <div class="form-group">
            <label>Old Password</label>
            <input type="password" name="old_password" required>
        </div>

        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="new_password" required>
        </div>

        <button type="submit" name="change_password" class="btn">Change Password</button>
    </form>
</div>

</div>

</body>
</html>