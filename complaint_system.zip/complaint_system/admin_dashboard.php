<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$sql = "SELECT complaints.*, users.name 
        FROM complaints 
        JOIN users ON complaints.user_id = users.id";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>

<body>

    <h2>Admin Panel</h2>
    <p>Welcome <?php echo $_SESSION['name']; ?> 👑</p>
    <a href="logout.php">Logout</a>

    <br><br>

    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Subject</th>
            <th>Description</th>
            <th>Status</th>
            <th>Update Status</th>
        </tr>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['subject']; ?></td>
                <td><?php echo $row['description']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <a href="update_status.php?id=<?php echo $row['id']; ?>&status=Approved">Approve</a> |
                    <a href="update_status.php?id=<?php echo $row['id']; ?>&status=Rejected">Reject</a>
                </td>
                <!-- <td>
        <a href="admin/delete_complaint.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this complaint?');">Delete</a>
    </td> -->
            </tr>
        <?php } ?>

    </table>

</body>

</html>