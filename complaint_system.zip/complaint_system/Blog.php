<?php
include "db.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog Page</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(to right, #fdfbfb, #ebedee);
}

/* HEADER */
header{
    background: linear-gradient(170deg,gray,black);
    color:white;
    padding:30px;
    text-align:center;
    font-size:28px;
    letter-spacing:1px;
    font-weight:bold;
}

/* CONTAINER */
.container{
    width:90%;
    max-width:1100px;
    margin:40px auto;
}
/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(83, 78, 78, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-weight:bold;
    font-size:18px;
}

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    transition:0.3s;
}

.nav-links a:hover{
    color:whitesmoke;
}
.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}

.nav-right button{
    margin-left:10px;
    padding:8px 15px;
    border:none;
    border-radius:20px;
    cursor:pointer;
}

.btn-outline{
    background:transparent;
    border:1px solid white;
    color:black;
}

.btn-primary{
    background:black;
    color:white;
}

/* BLOG CARD */
.blog-card{
    background:white;
    padding:25px;
    margin-bottom:25px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
    transition:0.3s;
}

.blog-card:hover{
    transform:translateY(-8px);
    box-shadow:0 15px 35px rgba(0,0,0,0.15);
}

/* TITLE */
.blog-title{
    font-size:24px;
    color:#333;
    margin-bottom:10px;
}

/* META */
.blog-meta{
    font-size:14px;
    color:gray;
    margin-bottom:15px;
}

/* CONTENT */
.blog-content{
    font-size:16px;
    color:#555;
    line-height:1.6;
}

/* READ MORE BUTTON */
.read-more{
    display:inline-block;
    margin-top:15px;
    padding:10px 18px;
    background:gray;
    color:white;
    border-radius:25px;
    text-decoration:none;
    font-size:14px;
    transition:0.3s;
}

.read-more:hover{
    background:black;
}

/* RESPONSIVE */
@media(max-width:768px){
    header{
        font-size:22px;
    }

    .blog-title{
        font-size:20px;
    }
}
/* BACK BUTTON */
.back-btn{
    display:inline-block;
    margin-top:25px;
    padding:10px 18px;
    background:gray;
    color:white;
    text-decoration:none;
    border-radius:25px;
    transition:0.3s;
}

.back-btn:hover{
    background:black;
}
</style>

</head>

<body>
    
<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
    <ul class="nav-links">
        <li><a href="Features.php">Features</a></li>
        <li><a href="Blog.php">Blog</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="Resources.php">Resources</a></li>
    </ul>

    <div class="nav-right">
        <button class="btn-outline" onclick="location.href='add_blog.php'">Add Blog</button>
        <button class="btn-primary" onclick="location.href='index.php'"> back to home</button>
    </div>
</nav>

<header>Complaint System Blog</header>

<div class="container">

<?php

$sql = "SELECT * FROM blog_posts ORDER BY created_at DESC";
$result = mysqli_query($conn,$sql);

while($row = mysqli_fetch_assoc($result))
{
?>

<div class="blog-card">

    <div class="blog-title">
        <?php echo $row['title']; ?>
    </div>

    <div class="blog-meta">
        By <b><?php echo $row['author']; ?></b> |
        <?php echo date("d M Y", strtotime($row['created_at'])); ?>
    </div>

    <div class="blog-content">
        <?php echo substr($row['content'], 0, 150); ?>...
    </div>

<a href="blog_details.php?id=<?php echo $row['id']; ?>" class="read-more">Read More</a>


 
</div>
 
<?php
}
?>

</div>
  <a href="index.php" class="back-btn">← Back to Home Page</a>
</body>
</html>