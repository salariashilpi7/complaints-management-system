<?php
include 'db.php';

$error = "";
$success = "";

if(isset($_POST['register'])){

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Check if email exists
    $check = $conn->prepare("SELECT * FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if($result->num_rows > 0){
        $error = "Email already registered!";
    } else {

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)");
        $stmt->bind_param("ssss", $name, $email, $hashed_password, $role);

        if($stmt->execute()){
            $success = "Registration Successful! Redirecting...";
            header("refresh:2;url=login.php");
        } else {
            $error = "Something went wrong!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    min-height:100vh;
    background: linear-gradient(170deg,gray,white);
    display:flex;
    flex-direction:column;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(89, 86, 86, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-weight:bold;
    font-size:18px;
}

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    transition:0.3s;
}

.nav-links a:hover{
    color:whitesmoke;
}
.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}

.nav-right button{
    margin-left:10px;
    padding:8px 15px;
    border:none;
    border-radius:20px;
    cursor:pointer;
}

.btn-outline{
    background:transparent;
    border:1px solid white;
    color:black;
}

.btn-primary{
    background:black;
    color:white;
}

/* FORM WRAPPER */
.wrapper{
    flex:1;
    display:flex;
    justify-content:center;
    align-items:center;
}

/* CARD */
.container{
    background:rgba(101, 98, 98, 0.15);
    backdrop-filter:blur(15px);
    padding:35px;
    border-radius:15px;
    width:350px;
    color:black;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

.container h2{
    text-align:center;
    margin-bottom:20px;
}

/* INPUT */
.input-box{
    margin-bottom:15px;
}

input, select{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    outline:none;
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background:black;
    color:whitesmoke;
    border:none;
    border-radius:25px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:gray;
}

/* ALERTS */
.error{
    background:red;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    text-align:center;
}

.success{
    background:green;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    text-align:center;
}

/* LOGIN LINK */
.login-link{
    text-align:center;
    margin-top:15px;
}

.login-link a{
    color:black;
    text-decoration:none;
}

.login-link a:hover{
    text-decoration:underline;
}

/* RESPONSIVE */
@media(max-width:768px){
    .navbar{
        flex-direction:column;
        gap:10px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    
 <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
    <ul class="nav-links">
        <li><a href="Features.php">Features</a></li>
        <li><a href="Blog.php">Blog</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="Resources.php">Resources</a></li>
    </ul>

    <div class="nav-right">
        <button class="btn-outline" onclick="location.href='register.php'">Sign up</button>
        <button class="btn-primary" onclick="location.href='login.php'">Login</button>
    </div>
</nav>

<!-- FORM -->
<div class="wrapper">
<div class="container">

<h2>Register</h2>

<?php if($error != ""){ ?>
<div class="error"><?php echo $error; ?></div>
<?php } ?>

<?php if($success != ""){ ?>
<div class="success"><?php echo $success; ?></div>
<?php } ?>

<form method="POST">

<div class="input-box">
    <input type="text" name="name" placeholder="Enter Name" required>
</div>

<div class="input-box">
    <input type="email" name="email" placeholder="Enter Email" required>
</div>

<div class="input-box">
    <input type="password" name="password" placeholder="Enter Password" required>
</div>

<div class="input-box">
    <select name="role" required>
        <option value="">Select Role</option>
        <option value="user">User</option>
        <!-- REMOVE admin option for security -->
    </select>
</div>

<button type="submit" name="register">Register</button>

</form>

<div class="login-link">
    Already have an account? <a href="login.php">Login</a>
</div>

</div>
</div>

</body>
</html>