<?php
include "db.php";

$success = "";
$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

$name = mysqli_real_escape_string($conn,$_POST['name']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$message = mysqli_real_escape_string($conn,$_POST['message']);

$sql = "INSERT INTO contacts (name,email,message) 
        VALUES ('$name','$email','$message')";

if(mysqli_query($conn,$sql)){
    $success = "Message sent successfully!";
}else{
    $error = "Something went wrong!";
}

}
?>

<!DOCTYPE html>
<html>
<head>
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Us</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
<style>

body{
font-family: Arial;
background:#f4f4f4;
}

.contact-form{
width:400px;
margin:50px auto;
background:white;
padding:20px;
border-radius:5px;
box-shadow:0px 0px 10px rgba(0,0,0,0.1);
}

input, textarea{
width:100%;
padding:10px;
margin:10px 0;
border:1px solid #ccc;
border-radius:4px;
}

button{
background:gray;
color:black;
padding:10px;
border:none;
cursor:pointer;
width:100%;
}

.success{
color:green;
}

.error{
color:red;
}

</style>
</head>

<body>
<!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
        <ul class="nav-links">
            <li><a href="Features.php">Features</a></li>
            <li><a href="Blog.php">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="Resources.php">Resources</a></li>
        </ul>
        <div class="nav-right">
            <!-- <button class="btn-outline">Sign up</button> -->
            <button class="btn-outline" onclick="window.location.href='register.php'">
                Sign up
            </button>

            <!-- <button class="btn-primary">Login</button> -->
            <button class="btn-primary" onclick="window.location.href='login.php'">
                Login
        </div>
    </nav>
<div class="contact-form">

<h2>Contact Us</h2>

<?php if($success){ ?>
<p class="success"><?php echo $success; ?></p>
<?php } ?>

<?php if($error){ ?>
<p class="error"><?php echo $error; ?></p>
<?php } ?>

<form method="POST">

<input type="text" name="name" placeholder="Your Name" required>

<input type="email" name="email" placeholder="Your Email" required>

<textarea name="message" placeholder="Your Message" required></textarea>

<button type="submit">Send Message</button>

</form>

</div>

</body>
</html>