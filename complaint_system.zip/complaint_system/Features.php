<!DOCTYPE html>
<html>
<head> <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Our Features</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>

body{
font-family: Arial;
margin:0;
background:#f4f4f4;
}

.header{
text-align:center;
padding:40px;
background:#333;
color:white;
}

.features-container{
display:flex;
flex-wrap:wrap;
justify-content:center;
padding:30px;
}

.feature-box{
background:white;
width:250px;
margin:15px;
padding:20px;
border-radius:8px;
box-shadow:0 0 10px rgba(0,0,0,0.1);
text-align:center;
transition:0.3s;
}

.feature-box:hover{
transform:scale(1.05);
}

.feature-icon{
font-size:40px;
margin-bottom:10px;
}

</style>

</head>

<body>
<!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
        <ul class="nav-links">
            <li><a href="Features.php">Features</a></li>
            <li><a href="Blog.php">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="Resources.php">Resources</a></li>
        </ul>
        <div class="nav-right">
            <!-- <button class="btn-outline">Sign up</button> -->
            <button class="btn-outline" onclick="window.location.href='register.php'">
                Sign up
            </button>

            <!-- <button class="btn-primary">Login</button> -->
            <button class="btn-primary" onclick="window.location.href='login.php'">
                Login
        </div>
    </nav>
<div class="header">
<h1>Our Features</h1>
<p>Explore what our platform offers</p>
</div>

<div class="features-container">

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-pen-nib"></i></div>
<h3>Blog System</h3>
<p>Create and read blogs easily with a simple interface.</p>
</div>

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-lock"></i></div>
<h3>Secure Login</h3>
<p>User authentication system with secure login.</p>
</div>

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-user-shield"></i></div>
<h3>Admin Panel</h3>
<p>Admin can manage blogs, users and content.</p>
</div>

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-envelope"></i></div>
<h3>Contact System</h3>
<p>Users can send messages through contact form.</p>
</div>

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-bolt"></i></div>
<h3>Fast Performance</h3>
<p>Optimized system for faster loading.</p>
</div>

<div class="feature-box">
<div class="feature-icon"><i class="fa-solid fa-mobile-screen-button"></i></div>
<h3>Responsive Design</h3>
<p>Works perfectly on mobile, tablet and desktop.</p>
</div>

</div>

</body>
</html>