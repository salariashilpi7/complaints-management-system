<?php
session_start();
include 'db.php';

if ($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$status = $_GET['status'];

$sql = "UPDATE complaints SET status='$status' WHERE id='$id'";

mysqli_query($conn, $sql);

header("Location: admin_dashboard.php");
?>