<html>

<head> <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Home Page</title>
</head>

<body>
 
   <!-- Navbar -->
    <nav class="navbar">
        <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
        <ul class="nav-links">
            <li><a href="Features.php">Features</a></li>
            <li><a href="Blog.php">Blog</a></li>
            <li><a href="contact.php">Contact</a></li>
            <li><a href="Resources.php">Resources</a></li>
        </ul>
        <div class="nav-right">
            <!-- <button class="btn-outline">Sign up</button> -->
            <button class="btn-outline" onclick="window.location.href='register.php'">
                Sign up
            </button>

            <!-- <button class="btn-primary">Login</button> -->
            <button class="btn-primary" onclick="window.location.href='login.php'">
                Login
        </div>
    </nav>

    <!-- Main Section -->
    <section class="main">
        <div class="main-text">
            <h1>Complaints<br>resolved<br>without the <br>noise</h1>
            <p>Submit complaints online and track them in real time.
                No more lost paperwork, no more waiting in lines.
                Just clean, direct resolution.</p>
            <div class="main-buttons">
                <!-- <button class="btn-primary">Register Complaint</button> -->

                <button class="btn-primary" onclick="window.location.href='complaint.php'">
                    Register Complaint
                </button>

                <!-- <button class="btn-outline">Learn more</button> -->
                <button class="btn-outline" onclick="window.location.href='features.php'">
                    Learn more
                </button>
            </div>
        </div>

        <div class="main-image">
            <img src="main.jpeg" alt="Main Image">
        </div>
    </section>
</body>

</html>