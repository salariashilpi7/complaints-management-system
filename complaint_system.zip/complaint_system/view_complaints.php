<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch complaints of logged in user
$result = $conn->query("SELECT * FROM complaints WHERE user_id='$user_id' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Complaints</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(135deg,gray,white);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(54, 50, 50, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-size:18px;
    font-weight:bold;
}.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}

 

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    transition:0.3s;
}

.nav-links a:hover{
    color:gray;
}

.logout{
    background:black;
    color:white;
    padding:8px 15px;
    border-radius:20px;
    text-decoration:none;
}

/* CONTAINER */
.container{
    width:90%;
    max-width:1100px;
    margin:40px auto;
    color:black;
}

/* TITLE */
.title{
    font-size:28px;
    margin-bottom:20px;
}

/* TABLE */
.table{
    width:100%;
    border-collapse:collapse;
    background:rgba(255,255,255,0.1);
    backdrop-filter:blur(10px);
    border-radius:10px;
    overflow:hidden;
}

.table th, .table td{
    padding:15px;
    text-align:left;
}

.table th{
    background:rgba(0,0,0,0.2);
}

.table tr{
    border-bottom:1px solid rgba(255,255,255,0.1);
}

.table tr:hover{
    background:rgba(255,255,255,0.1);
}

/* STATUS */
.status{
    padding:5px 12px;
    border-radius:20px;
    font-size:12px;
}

.pending{
    background:whitesmoke;
    color:black;
}

.resolved{
    background:green;
}

/* NO DATA */
.no-data{
    text-align:center;
    margin-top:50px;
    font-size:18px;
}

/* RESPONSIVE */
@media(max-width:768px){
    .table{
        font-size:12px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
     <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>

    <ul class="nav-links">
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="complaint.php">Complaint</a></li>
        <li><a href="view_complaints.php">My Complaints</a></li>
    </ul>

    <a href="logout.php" class="logout">Logout</a>
</nav>

<div class="container">

<div class="title">📋 My Complaints</div>

<?php if($result->num_rows > 0){ ?>

<table class="table">
    <tr>
        <th>ID</th>
        <th>Subject</th>
        <th>Description</th>
        <th>Status</th>
        <th>Date</th>
    </tr>

    <?php while($row = $result->fetch_assoc()){ ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['subject']; ?></td>
        <td><?php echo $row['description']; ?></td>
        <td>
            <span class="status <?php echo $row['status']=='Resolved' ? 'resolved':'pending'; ?>">
                <?php echo $row['status']; ?>
            </span>
        </td>
        <td><?php echo $row['created_at']; ?></td>
    </tr>
    <?php } ?>

</table>

<?php } else { ?>

<div class="no-data">
    😔 You have not submitted any complaints yet.
</div>

<?php } ?>

</div>

</body>
</html>