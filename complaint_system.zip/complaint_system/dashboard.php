<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    background: linear-gradient(170deg,gray,white);
    min-height:100vh;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(53, 51, 51, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-size:18px;
    font-weight:bold;
}.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}


.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    transition:0.3s;
}

.nav-links a:hover{
    color:whitesmoke;
}

/* DASHBOARD */
.container{
    width:90%;
    max-width:1100px;
    margin:40px auto;
    color:black;
}

/* WELCOME */
.welcome{
    font-size:28px;
    margin-bottom:10px;
}

.subtext{
    margin-bottom:30px;
}

/* CARDS */
.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(250px,1fr));
    gap:20px;
}

.card{
    background:rgba(255,255,255,0.15);
    backdrop-filter:blur(15px);
    padding:25px;
    border-radius:15px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,0.2);
    transition:0.3s;
}

.card:hover{
    transform:translateY(-8px);
}

/* BUTTON */
.btn{
    display:inline-block;
    margin-top:15px;
    padding:10px 20px;
    background:black;
    color:white;
    border-radius:25px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}

.btn:hover{
    background:gray;
}

/* LOGOUT */
.logout{
    float:right;
    background:black;
    color:white;
    padding:8px 15px;
    border-radius:20px;
    text-decoration:none;
}

.logout:hover{
    background:gray;
}

/* RESPONSIVE */
@media(max-width:768px){
    .navbar{
        flex-direction:column;
        gap:10px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>

    <ul class="nav-links">
        <li><a href="dashboard.php">Home</a></li>
        <li><a href="complaint.php">Complaint</a></li>
        <li><a href="blog.php">Blog</a></li>
    </ul>

    <a href="logout.php" class="logout">Logout</a>
</nav>

<!-- DASHBOARD CONTENT -->
<div class="container">

<div class="welcome">
    Welcome, <?php echo $_SESSION['name']; ?> 🎉
</div>

<div class="subtext">
    You have successfully logged into your dashboard.
</div>

<!-- CARDS -->
<div class="cards">

    <div class="card">
        <h3>Submit Complaint</h3>
        <p>Raise a new issue or complaint.</p>
        <a href="complaint.php" class="btn">Submit</a>
    </div>

    <div class="card">
        <h3>My Complaints</h3>
        <p>View your submitted complaints.</p>
        <a href="view_complaints.php" class="btn">View</a>
    </div>

    <div class="card">
        <h3>Profile</h3>
        <p>Manage your account details.</p>
        <a href="profile.php" class="btn">Open</a>
    </div>

</div>

</div>

</body>
</html>