<?php
include "db.php";

if (isset($_POST['submit'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $author = $_POST['author'];

    $sql = "INSERT INTO blog_posts(title,content,author)
            VALUES('$title','$content','$author')";

    mysqli_query($conn, $sql);

    echo "<p class='success'>Blog Added Successfully</p>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Blog</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    min-height:100vh;
    background: linear-gradient(170deg, gray, white);
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(89, 86, 86, 0.1);
    backdrop-filter:blur(10px);
}
.logo{
    font-weight:bold;
    font-size:18px;
}

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    transition:0.3s;
}

.nav-links a:hover{
    color:gray;
}
.logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}

.nav-right button{
    margin-left:10px;
    padding:8px 15px;
    border:none;
    border-radius:20px;
    cursor:pointer;
}

.btn-outline{
    background:transparent;
    border:1px solid black;
    color:black;
}

.btn-primary{
    background:black;
    color:white;
}

/* FORM WRAPPER */
.wrapper{
    display:flex;
    justify-content:center;
    align-items:center;
    height:80vh;
}

/* CARD */
.container{
    background:rgba(101, 98, 98, 0.15);
    backdrop-filter:blur(15px);
    padding:35px;
    border-radius:15px;
    width:350px;
    color:black;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

.container h2{
    text-align:center;
    margin-bottom:20px;
}

/* INPUT */
input, textarea{
    width:100%;
    padding:10px;
    margin-top:5px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:5px;
    outline:none;
}

textarea{
    height:120px;
    resize:none;
}

/* BUTTON */
.container button{
    width:100%;
    padding:12px;
    background:black;
    color:white;
    border:none;
    border-radius:25px;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

.container button:hover{
    background:gray;
}

/* SUCCESS MESSAGE */
.success{
    text-align:center;
    color:green;
    font-weight:bold;
    margin-top:10px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
     <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>

    <ul class="nav-links">
        <li><a href="Features.php">Features</a></li>
        <li><a href="Blog.php">Blog</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="Resources.php">Resources</a></li>
    </ul>

    <div class="nav-right">
        <button class="btn-outline" onclick="location.href='Blog.php'">back to page </button>
        <button class="btn-primary" onclick="location.href='blog_details.php'"> Blogs Details</button>
    </div>
</nav>

<!-- FORM -->
<div class="wrapper">
    <div class="container">

        <h2>Add Blog Post</h2>

        <form method="POST">

            <label>Title</label>
            <input type="text" name="title" required>

            <label>Author</label>
            <input type="text" name="author" required>

            <label>Content</label>
            <textarea name="content" required></textarea>

            <button type="submit" name="submit">Add Blog</button>

        </form>

    </div>
</div>

</body>
</html>