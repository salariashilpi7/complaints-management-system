<?php
session_start();
include 'db.php';

$error = "";

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);
    $user = mysqli_fetch_assoc($result);

    if($user && password_verify($password, $user['password'])){
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        if($user['role'] == 'admin'){
            header("Location: admin_dashboard.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    } else {
        $error = "Invalid Email or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login</title>

<style>

/* RESET */
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* BODY */
body{
    height:100vh;
    background: linear-gradient(170deg,gray,white);
    display:flex;
    flex-direction:column;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(105, 101, 101, 0.1);
    backdrop-filter:blur(10px);
    color:black;
}

.logo{
    font-weight:bold;
    font-size:18px;
}

.nav-links{
    list-style:none;
    display:flex;
    gap:20px;
}

.nav-links a{
    color:black;
    text-decoration:none;
    font-size:14px;
    transition:0.3s;
}

.nav-links a:hover{
    color:whitesmoke;
}
 .logo {
    display: flex;
    align-items: center;
    font-weight: bold;
}

.logo img{
    width: 80px;
}


.nav-right button{
    margin-left:10px;
    padding:8px 15px;
    border:none;
    border-radius:20px;
    cursor:pointer;
}

.btn-outline{
    background:transparent;
    border:1px solid white;
    color:black;
}

.btn-primary{
    background:black;
    color:white;
}

/* LOGIN BOX */
.wrapper{
    flex:1;
    display:flex;
    justify-content:center;
    align-items:center;
}

.container{
    background:rgba(255,255,255,0.15);
    backdrop-filter:blur(15px);
    padding:35px;
    border-radius:15px;
    width:350px;
    color:black;
    box-shadow:0 10px 30px rgba(0,0,0,0.2);
}

.container h2{
    text-align:center;
    margin-bottom:20px;
}

/* INPUT */
.input-box{
    position:relative;
    margin-bottom:20px;
}

.input-box input{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    outline:none;
}

.input-box input:focus{
    box-shadow:0 0 8px rgba(255,255,255,0.5);
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background:black;
    border:none;
    border-radius:25px;
    color:white;
    font-weight:bold;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:gray;
}

/* ERROR */
.error{
    background:gray;
    padding:10px;
    border-radius:6px;
    margin-bottom:15px;
    text-align:center;
}

/* RESPONSIVE */
@media(max-width:768px){
    .navbar{
        flex-direction:column;
        gap:10px;
    }
}

</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo"><img src="logo.png" alt="Logo">Online Complaints Management System</div>
    <ul class="nav-links">
        <li><a href="Features.php">Features</a></li>
        <li><a href="Blog.php">Blog</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="Resources.php">Resources</a></li>
    </ul>

    <div class="nav-right">
        <button class="btn-outline" onclick="location.href='register.php'">Sign up</button>
        <button class="btn-primary" onclick="location.href='login.php'">Login</button>
    </div>
</nav>

<!-- LOGIN FORM -->
<div class="wrapper">
<div class="container">

<h2>Login</h2>

<?php if($error != ""){ ?>
<div class="error"><?php echo $error; ?></div>
<?php } ?>

<form method="POST">

<div class="input-box">
    <input type="email" name="email" placeholder="Enter Email" required>
</div>

<div class="input-box">
    <input type="password" name="password" placeholder="Enter Password" required>
</div>

<button type="submit" name="login">Login</button>

</form>

</div>
</div>

</body>
</html>