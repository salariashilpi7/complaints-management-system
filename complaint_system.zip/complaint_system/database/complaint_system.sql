-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 14, 2026 at 06:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `complaint_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `title`, `content`, `author`, `created_at`) VALUES
(3, 'Turning Complaints into Opportunities: Building an Effective Complaint Management System', 'Introduction\r\nIn today’s fast-paced world, customer satisfaction is the heartbeat of any successful organization. But let’s face it—complaints are inevitable. Instead of viewing them as setbacks, a well-designed Complaint Management System (CMS) can transform grievances into valuable insights, helping businesses improve, innovate, and build stronger relationships with their customers.\r\nWhy a Complaint Management System Matters\r\nA CMS is more than just a digital suggestion box—it’s a structured process that ensures every concern is heard, tracked, and resolved efficiently. Without it, complaints can slip through the cracks, leading to frustration, negative reviews, and lost trust.\r\nKey Benefits of a Complaint Management System\r\n\r\nFaster Resolution: Automates tracking and assigns complaints to the right team instantly.\r\n\r\n\r\nTransparency: Keeps customers informed about the status of their complaint.\r\n\r\n\r\nData-Driven Insights: Identifies recurring issues to prevent future problems.\r\n\r\n\r\nCustomer Loyalty: Shows customers you value their feedback and are committed to improvement.\r\n\r\nEssential Features to Include\r\n\r\nUser-Friendly Interface – Simple complaint submission for customers and easy navigation for staff.\r\n\r\n\r\nAutomated Ticketing – Assigns and prioritizes complaints based on urgency.\r\n\r\n\r\nReal-Time Tracking – Allows both customers and staff to monitor progress.\r\n\r\n\r\nAnalytics Dashboard – Provides reports for performance evaluation and trend analysis.\r\n\r\n\r\nMulti-Channel Support – Accepts complaints via email, web forms, chat, or mobile apps.\r\n\r\nBest Practices for Implementation\r\n\r\nTrain your team to handle complaints empathetically.\r\n\r\n\r\nSet clear timelines for resolution.\r\n\r\n\r\nRegularly review complaint data to improve processes.\r\n\r\n\r\nCommunicate updates proactively to customers.\r\n\r\nConclusion\r\nA Complaint Management System isn’t just about fixing problems—it’s about building trust. By addressing issues promptly and transparently, you turn dissatisfied customers into loyal advocates. In the end, every complaint is an opportunity to grow stronger.\r\n\r\nIf you’d like, I can also create a short SEO-friendly meta description and five blog subheadings to make this post more search-friendly. Would you like me to prepare that?\r\n', 'Muskan ', '2026-03-12 06:26:02');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `user_id`, `subject`, `description`, `status`, `created_at`) VALUES
(2, 3, 'lab problem', 'there is no proper internet connection to computer', 'Approved', '2026-02-19 14:21:06'),
(4, 5, 'lab problem', 'zxzxz', 'Pending', '2026-02-27 07:45:34'),
(5, 7, 'sssss', 'dfdsf gfgfdg fdgfdgfdgdf', 'Pending', '2026-04-14 16:44:28');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 'sneha', 'sneha@gmail.com', 'i need help', '2026-03-12 12:59:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Muskan Kaur', 'muskankaur1085@gmail.com', '$2y$10$gX0rU8Q76lrTWbxDk0WZx.vBTohEPJ0Px7OlWfXjCQrbC6XKKvMCq', 'admin'),
(2, 'Shilpi', 'shilpisalaria7@gmail.com', '$2y$10$q733rjp4Q/ACCH6qjwgMVOf94i.oKXr.UT6lbXX44Ki8FKcmhoxRe', 'user'),
(3, 'Sumit Kumar', 'sumitkwn@gmail.com', '$2y$10$o7rqIrnZliPtmkgCxV5w5.bissf.B.a1eC0G3scK.QUv/2z8UXIYy', 'user'),
(4, 'sakshi', 'sakshiarya104@gmail.com', '$2y$10$ah7tYmCrpwFvEljRshVXgOR5gbaUdmx/JLAB4iRG8.cYnpt0HmMkO', 'user'),
(5, 'amit', 'amit455kwn@gmail.com', '$2y$10$GDHhSYzJpoRSKeRASDrdyOMxS63BSQh9HYtWOOGCsMnuR1BhrLSxG', 'user'),
(7, 'namish', 'aaa@gmail.com', '$2y$10$w26MiEGB/zvEiym/Vy0sj.ZJXUkwCPITfhAhULGCnrkGr/u7A51tC', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
